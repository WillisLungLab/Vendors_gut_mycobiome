
######### Libraries
library(mvabund)
library(ggplot2)
library(phyloseq)
library(vegan)
library(reshape2)
library(corrplot)
library(ggcorrplot)
library(Hmisc)
library(fossil)
library(viridis)
library(hrbrthemes)

######### Files
setwd("/Users/justinstewart/Dropbox/Collaborations/Kent:Joe/No_HDF/")

bact.otu<-data.matrix(read.csv("./16s_Order.csv", header=TRUE, row.names = 1))
fung.otu<-data.matrix(read.csv(file="./ITS_Order.csv", header=T,row.names = 1))

b.map<-read.csv(file="./Map_Bacteria.csv", header=T, row.names = 1)
f.map<-read.csv(file="./Map_Fungi.csv", header=T, row.names = 1)
dim(f.map)
dim(fung.otu)
dim(bact.otu)

######## MVABUND


dim(b.map)
dim(bact.otu)
# Build and run model (check data distribution first, if microbes prob neg bin)
meanvar.plot(bact.otu)
mod1.bact <- manyglm(bact.otu ~ b.map$Gender, family="negative_binomial") #Build and run model
plot(mod1.bact) #Check distribution or residuals

b.gen<-anova(mod1.bact,nBoot=1000)

mod2.bact <- manyglm(bact.otu ~ b.map$Vendor, family="negative_binomial") #Build and run model
plot(mod2.bact) #Check distribution or residuals

b.ven<-anova(mod2.bact,nBoot=1000)

mod3.bact <- manyglm(bact.otu ~ b.map$Diet, family="negative_binomial") #Build and run model
plot(mod3.bact) #Check distribution or residuals

b.diet<-anova(mod3.bact,nBoot=1000) 

mod4.bact <- manyglm(bact.otu ~ b.map$Timepoint, family="negative_binomial") #Build and run model
plot(mod4.bact) #Check distribution or residuals

b.time<-anova(mod4.bact,nBoot=1000) 

mod5.bact <- manyglm(bact.otu ~ b.map$Timepoint, family="negative_binomial") #Build and run model
plot(mod5.bact) #Check distribution or residuals

b.time.uni<-anova(mod5.bact,p.uni="adjusted",nBoot=1000) 
b.time.uni$uni.p

#fungus 


meanvar.plot(fung.otu)
mod1.fung <- manyglm(fung.otu ~ f.map$Sex, family="negative_binomial") #Build and run model
plot(mod1.fung) #Check distribution or residuals

f.sex<-anova(mod1.fung, nBoot=1000)
f.sex

mod2.fung <- manyglm(fung.otu ~ f.map$Vendor, family="negative_binomial") #Build and run model
plot(mod2.fung) #Check distribution or residuals

f.ven<-anova(mod2.fung, nBoot=1000)
f.ven

mod3.fung <- manyglm(fung.otu ~ f.map$Diet, family="negative_binomial") #Build and run model
plot(mod3.fung) #Check distribution or residuals

f.diet<-anova(mod3.fung, nBoot=1000)
f.diet

mod4.fung <- manyglm(fung.otu ~ f.map$Timepoint, family="negative_binomial") #Build and run model
plot(mod4.fung) #Check distribution or residuals

f.time<-anova(mod4.fung, nBoot=1000)
f.time

# univariate 


mod5.fung <- manyglm(fung.otu ~ f.map$Timepoint, family="negative_binomial") #Build and run model
plot(mod5.fung) #Check distribution or residuals

f.time<-anova(mod5.fung, nBoot=1000, p.uni="adjusted")
write.csv(f.time$uni.p, file="MVABUND_Results/Fungus_Time.csv")

mod6.fung <- manyglm(fung.otu ~ f.map$Diet, family="negative_binomial") #Build and run model
plot(mod6.fung) #Check distribution or residuals

f.diet<-anova(mod6.fung, nBoot=1000, p.uni="adjusted")
write.csv(f.diet$uni.p, file="MVABUND_Results/Fungus_diet.csv")

mod7.fung <- manyglm(fung.otu ~ f.map$Sex, family="negative_binomial") #Build and run model
plot(mod7.fung) #Check distribution or residuals

f.sex<-anova(mod7.fung, nBoot=1000, p.uni="adjusted")
write.csv(f.sex$uni.p, file="MVABUND_Results/Fungus_sex.csv")

mod8.fung <- manyglm(fung.otu ~ f.map$Vendor, family="negative_binomial") #Build and run model
plot(mod8.fung) #Check distribution or residuals

f.vend<-anova(mod8.fung, nBoot=1000, p.uni="adjusted")
write.csv(f.vend$uni.p, file="MVABUND_Results/Fungus_vendor.csv")




######## Heatmap

library(ggcorrplot)
in.cor<-read.csv(file="./Interkingdom.csv", header=T)
in.cor<-na.omit(in.cor)
corr<-cor(in.cor,method = "spearman")
p.mat <- cor_pmat(in.cor)

ggcorrplot(corr,hc.order = T)

mc1<-melt(corr)
hist(mc1$value)

in.b.cor<-read.csv(file="./Correlations/Co-Occur/Interkingdom_baseline.csv", header=T, row.names = 1)
corr_b<-cor(t(in.b.cor),method = "spearman")
p.mat_b <- cor_pmat(in.b.cor)
mcb<-melt(corr_b)

ggcorrplot(corr_b, tl.cex = 6)

in.e.cor<-read.csv(file="./Interkingdom_endpoint.csv", header=T, row.names = 1)
corr_e<-cor(t(in.e.cor),method = "spearman")
p.mat_c <- cor_pmat(in.e.cor)

mce<-melt(corr_e)

ggcorrplot(corr_e, tl.cex=6)

endcor<-na.omit(mce$value)
begcor<-na.omit(mcb$value)

hist(endcor)
hist(begcor)

ggplot(mcb, aes(x=mcb$value)) + geom_density(fill="#1DACE8") + 
  geom_vline(aes(xintercept=mean(mcb$value)),
               color="#F24D29", linetype="dashed", size=1) + 
  theme_bw() + theme(panel.border = element_blank(), panel.grid.major = element_blank(),
                     panel.grid.minor = element_blank(), axis.line = element_line(colour = "black"))+
  xlab("Spearman's Rho")

chow.cor<-read.csv(file="./Correlations/Co-Occur/Interkingdom_Chow.csv", header=T, row.names = 1)
corr_b<-cor(t(in.b.cor),method = "spearman")
p.mat_b <- cor_pmat(in.b.cor)
mcb<-melt(corr_b)

ggcorrplot(corr_b, tl.cex = 6)




#################
################
################
library(randomForest)
library(vegan)
require(caTools)
library(caret)
library(mlbench)
library(reprtree)
library(ranger)
library(tidyverse)
library(reshape2)
library(ggplot2)

data<-read.csv(file="./ITS_MachineLearning.csv", header=T, row.names = 1) #import data
dim(data)
transformed_data<- decostand(data, method = "hellinger") #transform
write.csv(transformed_data,"./ML_transformed.csv") #export and append with appropriate mapping data


##### Fat RFR ####

dataset.fat<-read.csv(file="./ML/ML_fat.csv", header=T) #addpend column 1 with your data catagory of interest

#PreProcess Data 

descrCor <-  cor(dataset.fat) #correlations
highCorr <- sum(abs(descrCor[upper.tri(descrCor)]) > .99) # highly correlated
dataset.fat <- dataset.fat[,-highCorr]


pp.fat <- preProcess(dataset.fat[-1], method = c("center", "scale"))
transformed.fat <- predict(pp.fat, newdata = dataset.fat[, -1])
working.fat<-cbind(dataset.fat$Fat...Delta..absolute.change.from.baseline.,transformed)



# create a list of 60% of the rows in the original dataset we can use for training
validation_index.fat <- createDataPartition(working.fat$`dataset.fat$Fat...Delta..absolute.change.from.baseline.`, p=0.60, list=FALSE)
# select 40% of the data for validation
validation.fat<-working.fat[-validation_index.fat,]

# Run algorithms using 10-fold cross validation
control <- trainControl(method="cv", number=10)
metric <- "RMSE"

# Random Forest
set.seed(69)
fit.rf.fat <- train(`dataset.fat$Fat...Delta..absolute.change.from.baseline.`~., data=working.fat, method="rf", metric=metric, trControl=control)
fit.rf.fat


# Model Preformnance
predictions <- predict(fit.rf.fat, validation.fat)
RMSE(predictions,validation.fat$`dataset.fat$Fat...Delta..absolute.change.from.baseline.`)

plot(fit.rf.fat$finalModel)


# Variable importance 
rfImp.fat <- varImp(fit.rf.fat)
plot(rfImp.fat,top = 10)


##### Trig RFR ####

dataset.trig<-read.csv(file="./ML/ML_trig.csv", header=T) #append column 1 with your data catagory of interest

#PreProcess Data 

descrCor <-  cor(dataset.trig) #correlations
highCorr <- sum(abs(descrCor[upper.tri(descrCor)]) > .99) # highly correlated
dataset.trig <- dataset.trig[,-highCorr]


pp.trig <- preProcess(dataset.trig, method = c("center", "scale"))
transformed.trig <- predict(pp.trig, newdata = dataset.trig[, -1])
working.trig<-cbind(dataset.trig$Triglycerides,transformed.trig)


# create a list of 60% of the rows in the original dataset we can use for training
validation_index.trig <- createDataPartition(working.trig$`dataset.trig$Triglycerides`, p=0.60, list=FALSE)
# select 40% of the data for validation
validation.trig<-working.trig[-validation_index.trig,]

# Run algorithms using 10-fold cross validation
control <- trainControl(method="cv", number=10)
metric <- "RMSE"

# Random Forest
set.seed(69)
fit.rf.trig <- train(`dataset.trig$Triglycerides`~., data=working.trig, method="rf", metric=metric, trControl=control)
fit.rf.trig


# Model Preformnance
predictions <- predict(fit.rf.trig, validation.trig)
RMSE(predictions,validation.trig$Triglycerides)

plot(fit.rf.trig$finalModel)


# Variable importance 
rfImp.trig <- varImp(fit.rf.trig)
plot(rfImp.trig,top = 10)


##### Insulin RFR ####

dataset.insu<-read.csv(file="./ML/ML_insu.csv", header=T) #append column 1 with your data catagory of interest

#PreProcess Data 

descrCor <-  cor(dataset.insu) #correlations
highCorr <- sum(abs(descrCor[upper.tri(descrCor)]) > .99) # highly correlated
dataset.insu <- dataset.insu[,-highCorr]


pp.insu <- preProcess(dataset.insu[,-1], method = c("center", "scale"))
transformed.insu <- predict(pp.insu, newdata =dataset.insu)
working.insu<-transformed.insu


# create a list of 60% of the rows in the original dataset we can use for training
validation_index.insu <- createDataPartition(working.insu$Insulin, p=0.60, list=FALSE)
# select 40% of the data for validation
validation.insu<-working.insu[-validation_index.insu,]

# Run algorithms using 10-fold cross validation
control <- trainControl(method="cv", number=10)
metric <- "RMSE"

# Random Forest
set.seed(69)
fit.rf.insu <- train(Insulin~., data=working.insu, method="rf", metric=metric, trControl=control)
fit.rf.insu


# Model Preformnance
predictions <- predict(fit.rf.insu, validation.insu)
RMSE(predictions,validation.insu$Insulin)

plot(fit.rf.insu$finalModel)


# Variable importance 
rfImp.insu <- varImp(fit.rf.insu)
plot(rfImp.insu,top = 10)


##### Leptin RFR ####

dataset.leptin<-read.csv(file="./ML/ML_leptin.csv", header=T) #append column 1 with your data catagory of interest


#PreProcess Data 

descrCor <-  cor(dataset.leptin) #correlations
highCorr <- sum(abs(descrCor[upper.tri(descrCor)]) > .99) # highly correlated
dataset.leptin <- dataset.leptin[,-highCorr]

pp.leptin <- preProcess(dataset.leptin[,-1], method = c("center", "scale"))
transformed.leptin <- predict(pp.leptin, newdata =dataset.leptin)
working.leptin<-transformed.leptin


# create a list of 60% of the rows in the original dataset we can use for training
validation_index.leptin <- createDataPartition(working.leptin$Leptin, p=0.60, list=FALSE)
# select 40% of the data for validation
validation.leptin<-working.leptin[-validation_index.leptin,]

# Run algorithms using 10-fold cross validation
control <- trainControl(method="cv", number=10)
metric <- "RMSE"

# Random Forest
set.seed(69)
fit.rf.lept <- train(Leptin~., data=working.leptin, method="rf", metric=metric, trControl=control)
fit.rf.lept


# Model Preformnance
predictions <- predict(fit.rf.lept, validation.leptin)
RMSE(predictions,validation.leptin$Leptin)

plot(fit.rf.lept$finalModel)


# Variable importance 
rfImp.lept <- varImp(fit.rf.lept)
plot(rfImp.lept,top = 10)

##### Glucagon RFR ####

dataset.gluc<-read.csv(file="./ML/ML_gluc.csv", header=T) #append column 1 with your data catagory of interest


#PreProcess Data 

descrCor <-  cor(dataset.gluc) #correlations
highCorr <- sum(abs(descrCor[upper.tri(descrCor)]) > .99) # highly correlated
dataset.gluc <- dataset.gluc[,-highCorr]

pp.gluc <- preProcess(dataset.gluc[,-1], method = c("center", "scale"))
transformed.gluc <- predict(pp.gluc, newdata =dataset.gluc)
working.gluc<-transformed.gluc


# create a list of 60% of the rows in the original dataset we can use for training
validation_index.gluc <- createDataPartition(working.gluc$Glucagon, p=0.60, list=FALSE)
# select 40% of the data for validation
validation.gluc<-working.gluc[-validation_index.gluc,]

# Run algorithms using 10-fold cross validation
control <- trainControl(method="cv", number=10)
metric <- "RMSE"

# Random Forest
set.seed(69)
fit.rf.gluc <- train(Glucagon~., data=working.gluc, method="rf", metric=metric, trControl=control)
fit.rf.gluc


# Model Preformnance
predictions <- predict(fit.rf.gluc, validation.gluc)
RMSE(predictions,validation.gluc$Glucagon)

plot(fit.rf.gluc$finalModel)


# Variable importance 
rfImp.gluc <- varImp(fit.rf.gluc)
plot(rfImp.gluc,top = 10)

##### ResistinRFR ####

dataset.Resistin<-read.csv(file="./ML/ML_res.csv", header=T) #append column 1 with your data catagory of interest


#PreProcess Data 

descrCor <-  cor(dataset.Resistin) #correlations
highCorr <- sum(abs(descrCor[upper.tri(descrCor)]) > .99) # highly correlated
dataset.Resistin <- dataset.Resistin[,-highCorr]

pp.Resistin <- preProcess(dataset.Resistin[,-1], method = c("center", "scale"))
transformed.Resistin <- predict(pp.Resistin, newdata =dataset.Resistin)
working.Resistin<-transformed.Resistin


# create a list of 60% of the rows in the original dataset we can use for training
validation_index.Resistin <- createDataPartition(working.Resistin$Resistin, p=0.60, list=FALSE)
# select 40% of the data for validation
validation.Resistin<-working.Resistin[-validation_index.Resistin,]

# Run algorithms using 10-fold cross validation
control <- trainControl(method="cv", number=10)
metric <- "RMSE"

# Random Forest
set.seed(69)
fit.rf.resistin <- train(Resistin~., data=working.Resistin, method="rf", metric=metric, trControl=control)
fit.rf.resistin


# Model Preformnance
predictions <- predict(fit.rf.resistin, validation.Resistin)
RMSE(predictions,validation.Resistin$Resistin)

plot(fit.rf.resistin$finalModel)

# Variable importance 
rfImp.resistin <- varImp(fit.rf.resistin)
plot(rfImp.resistin,top = 10)

##### GhrelinRFR ####

dataset.Ghrelin<-read.csv(file="./ML/ML_ghre.csv", header=T) #append column 1 with your data catagory of interest


#PreProcess Data 

descrCor <-  cor(dataset.Ghrelin) #correlations
highCorr <- sum(abs(descrCor[upper.tri(descrCor)]) > .999) # highly correlated
dataset.Ghrelin <- dataset.Ghrelin[,-highCorr]

pp.Ghrelin <- preProcess(dataset.Ghrelin[,-1], method = c("center", "scale"))
transformed.Ghrelin <- predict(pp.Ghrelin, newdata =dataset.Ghrelin)
working.Ghrelin<-transformed.Ghrelin


# create a list of 60% of the rows in the original dataset we can use for training
validation_index.Ghrelin <- createDataPartition(working.Ghrelin$Ghrelin, p=0.60, list=FALSE)
# select 40% of the data for validation
validation.Ghrelin<-working.Ghrelin[-validation_index.Ghrelin,]

# Run algorithms using 10-fold cross validation
control <- trainControl(method="cv", number=10)
metric <- "RMSE"

# Random Forest
set.seed(1)
fit.rf.ghrelin <- train(Ghrelin~., data=working.Ghrelin, method="rf", metric=metric, trControl=control)
fit.rf.ghrelin


# Model Preformnance
predictions <- predict(fit.rf.ghrelin, validation.Ghrelin)
RMSE(predictions,validation.Ghrelin$Ghrelin)

plot(fit.rf.ghrelin$finalModel)


# Variable importance 
rfImp.ghrelin <- varImp(fit.rf.ghrelin)
plot(rfImp.ghrelin,top = 10)

##### Pia1 RFR ####

dataset.Pia1<-read.csv(file="./ML/ML_pia1.csv", header=T) #append column 1 with your data catagory of interest


#PreProcess Data 

descrCor <-  cor(dataset.Pia1) #correlations
highCorr <- sum(abs(descrCor[upper.tri(descrCor)]) > .999) # highly correlated
dataset.Pia1 <- dataset.Pia1[,-highCorr]

pp.Pia1 <- preProcess(dataset.Pia1[,-1], method = c("center", "scale"))
transformed.Pia1 <- predict(pp.Pia1, newdata =dataset.Pia1)
working.Pia1<-transformed.Pia1


# create a list of 60% of the rows in the original dataset we can use for training
validation_index.Pia1 <- createDataPartition(working.Pia1$PIA.1, p=0.60, list=FALSE)
# select 40% of the data for validation
validation.Pia1<-working.Pia1[-validation_index.Pia1,]

# Run algorithms using 10-fold cross validation
control <- trainControl(method="cv", number=10)
metric <- "RMSE"

# Random Forest
set.seed(69)
fit.rf.pia1 <- train(PIA.1~., data=working.Pia1, method="rf", metric=metric, trControl=control)
fit.rf.pia1


# Model Preformnance
predictions <- predict(fit.rf.pia1, validation.Pia1)
RMSE(predictions,validation.Pia1$PIA.1)

plot(fit.rf.pia1$finalModel)


# Variable importance 
rfImp.pia1 <- varImp(fit.rf.pia1)
plot(rfImp.pia1,top = 10)


####### RFR Corr Heatmap

lfd.fung<-read.csv(file="./Correlations/Diet/ITS_Order_LFD.csv", header=T)

lfd.cor<-read.csv(file="./Correlations/Diet/divcor_lfd.csv", header = T) #reformat

lfd.cor.m<-melt(lfd.cor)

ggplot(lfd.cor.m, aes( x=X, y=variable, fill=value)) +geom_tile()  + coord_flip() +
  theme(panel.border = element_blank(), panel.grid.major = element_blank(),
         panel.grid.minor = element_blank(), axis.line = element_line(colour = "black"), axis.text.x = element_text(angle = 90), text = element_text(size=20)) +
  scale_fill_viridis(discrete=FALSE) +xlab("") +ylab("")

Chow.fung<-read.csv(file="./Correlations/Diet/ITS_Order_CHOW.csv", header=T)

cor(Chow.fung,Chow.fung)
write.csv(cor(Chow.fung,Chow.fung, method="spearman"), file="./Correlations/Diet/divcor_Chow.csv") #edit to corrs of interest 

Chow.cor<-read.csv(file="./Correlations/Diet/divcor_Chow.csv", header=T) #reformat
dim(Chow.fung)

Chow.cor.m<-melt(Chow.cor)

ggplot(Chow.cor.m, aes( x=X, y=variable, fill=value)) +geom_tile() + coord_flip()  +
  theme(panel.border = element_blank(), panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(), axis.line = element_line(colour = "black"), axis.text.x = element_text(angle = 90), text = element_text(size=20)) +
        scale_fill_viridis(discrete=FALSE) +xlab("") +ylab("")



##### MVABUND Graphs

mv.time<-read.csv(file="./MVABUND_Results/Time_Graph.csv", header=T)
mv.time
mv.t.m<-melt(mv.time)

ggplot(mv.t.m, aes(x=variable, y=log10(value), fill=X))  +geom_bar(stat="identity") +
  ylab("Log 10 Mean Taxon Count") +xlab("") + scale_fill_discrete(name = "Taxon") +
  theme_bw() + theme(panel.border = element_blank(), panel.grid.major = element_blank(),
                     panel.grid.minor = element_blank(), axis.line = element_line(colour = "black"), text=element_text(size=18))

mv.diet<-read.csv(file="./MVABUND_Results/Diet_graph.csv", header=T)
mv.diet
mv.d.m<-melt(mv.diet)

ggplot(mv.d.m, aes(x=variable, y=log10(value), fill=Diet))  +geom_bar(stat="identity") +
  ylab("Log 10 Mean Taxon Count") +xlab("") + scale_fill_discrete(name = "Taxon") +
  theme_bw() + theme(panel.border = element_blank(), panel.grid.major = element_blank(),
                     panel.grid.minor = element_blank(), axis.line = element_line(colour = "black"), text=element_text(size=18))

###### Body comp



fbc<-read.csv(file="./Prism/Body_Comp_Female.csv", header=T)
head(fbc)
fbc.m<-melt(fbc)

ggplot(fbc.m,aes(x=variable, y=value, fill=Group)) +geom_b(stat="identity") + ylab("Fat and Lean Mass (grams)") +xlab("") + scale_fill_discrete(name = "Taxon") +
  theme_bw() + theme(panel.border = element_blank(), panel.grid.major = element_blank(),axis.text.x = element_text(angle = 90),
                     panel.grid.minor = element_blank(), axis.line = element_line(colour = "black"), text=element_text(size=15)) 

mbc<-read.csv(file="./Prism/Body_Comp_MALE.csv", header=T)
head(mbc)
mbc.m<-melt(mbc)

ggplot(mbc.m,aes(x=variable, y=value, fill=Group)) +geom_boxplot()+ ylab("Fat and Lean Mass (grams)") +xlab("") + scale_fill_discrete(name = "Taxon") +
  theme_bw() + theme(panel.border = element_blank(), panel.grid.major = element_blank(),axis.text.x = element_text(angle = 90),
                     panel.grid.minor = element_blank(), axis.line = element_line(colour = "black"), text=element_text(size=15))


fcf<-read.csv(file="./Prism/Fat_Change_Female.csv", header=T)
fcf.m<-melt(fcf)

ggplot(fcf.m,aes(x=variable, y=value, fill=variable)) + geom_boxplot() +geom_jitter() + ylab("∆ Fat (grams)") +xlab("") + scale_fill_discrete(name = "Taxon") +
  theme_bw() + theme(panel.border = element_blank(), panel.grid.major = element_blank(),axis.text.x = element_text(angle = 90),
                     panel.grid.minor = element_blank(), axis.line = element_line(colour = "black"), text=element_text(size=15))

mcf<-read.csv(file="./Prism/Fat_Change_Male.csv", header=T)
mcf.m<-melt(mcf)

ggplot(mcf.m,aes(x=variable, y=value, fill=variable)) + geom_boxplot() +geom_jitter() + ylab("∆ Fat (grams)") +xlab("") + scale_fill_discrete(name = "Taxon") +
  theme_bw() + theme(panel.border = element_blank(), panel.grid.major = element_blank(),axis.text.x = element_text(angle = 90),
                     panel.grid.minor = element_blank(), axis.line = element_line(colour = "black"), text=element_text(size=15))

mbw<-read.csv(file="./Prism/Male_BodyWeight.csv", header=T)
mbw.m<-melt(mbw)

ggplot(mbw.m,aes(x=variable, y=value, fill=variable)) + geom_boxplot() +geom_jitter() + ylab("∆ Body Weight (grams)") +xlab("") + scale_fill_discrete(name = "Taxon") +
  theme_bw() + theme(panel.border = element_blank(), panel.grid.major = element_blank(),axis.text.x = element_text(angle = 90),
                     panel.grid.minor = element_blank(), axis.line = element_line(colour = "black"), text=element_text(size=15))


fbw<-read.csv(file="./Prism/Female_BodyWeight.csv", header=T)
fbw.m<-melt(fbw)

ggplot(fbw.m,aes(x=variable, y=value, fill=variable)) + geom_boxplot() +geom_jitter() + ylab("∆ Body Weight (grams)") +xlab("") + scale_fill_discrete(name = "Taxon") +
  theme_bw() + theme(panel.border = element_blank(), panel.grid.major = element_blank(),axis.text.x = element_text(angle = 90),
                     panel.grid.minor = element_blank(), axis.line = element_line(colour = "black"), text=element_text(size=15))

fl<-read.csv(file="./Prism/Female_Lean.csv", header=T)
fl.m<-melt(fl)

ggplot(fl.m,aes(x=variable, y=value, fill=variable)) +geom_boxplot() +geom_jitter() + ylab("∆ Body Lean %") +xlab("") + scale_fill_discrete(name = "Taxon") +
  theme_bw() + theme(panel.border = element_blank(), panel.grid.major = element_blank(),axis.text.x = element_text(angle = 90),
                     panel.grid.minor = element_blank(), axis.line = element_line(colour = "black"), text=element_text(size=15))

ml<-read.csv(file="./Prism/Male_Lean.csv", header=T)
ml.m<-melt(fl)

ggplot(ml.m,aes(x=variable, y=value, fill=variable)) + geom_boxplot() +geom_jitter() + ylab("∆ Body Lean %") +xlab("") + scale_fill_discrete(name = "Taxon") +
  theme_bw() + theme(panel.border = element_blank(), panel.grid.major = element_blank(),axis.text.x = element_text(angle = 90),
                     panel.grid.minor = element_blank(), axis.line = element_line(colour = "black"), text=element_text(size=15))

mew<-read.csv(file="./Prism/Male_eWAT.csv", header=T)
mew.m<-melt(mew)

ggplot(mew.m,aes(x=variable, y=value, fill=variable)) + geom_boxplot() +geom_jitter() + ylab("eWAT/BW %") +xlab("") + scale_fill_discrete(name = "Taxon") +
  theme_bw() + theme(panel.border = element_blank(), panel.grid.major = element_blank(),axis.text.x = element_text(angle = 90),
                     panel.grid.minor = element_blank(), axis.line = element_line(colour = "black"), text=element_text(size=15))


few<-read.csv(file="./Prism/Female_eWAT.csv", header=T)
few.m<-melt(few)

ggplot(few.m,aes(x=variable, y=value, fill=variable)) + geom_boxplot() +geom_jitter() + ylab("eWAT/BW %") +xlab("") + scale_fill_discrete(name = "Taxon") +
  theme_bw() + theme(panel.border = element_blank(), panel.grid.major = element_blank(),axis.text.x = element_text(angle = 90),
                     panel.grid.minor = element_blank(), axis.line = element_line(colour = "black"), text=element_text(size=15))

flv<-read.csv(file="./Prism/Female_Liver.csv", header=T)
flv.m<-melt(flv)

ggplot(flv.m,aes(x=variable, y=value, fill=variable)) + geom_boxplot() +geom_jitter() + ylab("Liver/BW %") +xlab("") + scale_fill_discrete(name = "Taxon") +
  theme_bw() + theme(panel.border = element_blank(), panel.grid.major = element_blank(),axis.text.x = element_text(angle = 90),
                     panel.grid.minor = element_blank(), axis.line = element_line(colour = "black"), text=element_text(size=15))

mlv<-read.csv(file="./Prism/Male_Liver.csv", header=T)
mlv.m<-melt(mlv)

ggplot(mlv.m,aes(x=variable, y=value, fill=variable)) + geom_boxplot() +geom_jitter() + ylab("Liver/BW %") +xlab("") + scale_fill_discrete(name = "Taxon") +
  theme_bw() + theme(panel.border = element_blank(), panel.grid.major = element_blank(),axis.text.x = element_text(angle = 90),
                     panel.grid.minor = element_blank(), axis.line = element_line(colour = "black"), text=element_text(size=15))

tf<-read.csv(file="./Prism/Trig_female.csv", header=T)
tf.m<-melt(tf)

ggplot(tf.m,aes(x=variable, y=value, fill=variable)) + geom_boxplot() +geom_jitter() + ylab("Triglycerides (mg/dL)") +xlab("") + scale_fill_discrete(name = "Taxon") +
  theme_bw() + theme(panel.border = element_blank(), panel.grid.major = element_blank(),axis.text.x = element_text(angle = 90),
                     panel.grid.minor = element_blank(), axis.line = element_line(colour = "black"), text=element_text(size=15))

tm<-read.csv(file="./Prism/Trig_male.csv", header=T)
tm.m<-melt(tm)

ggplot(tm.m,aes(x=variable, y=value, fill=variable)) + geom_boxplot() +geom_jitter() + ylab("Triglycerides (mg/dL)") +xlab("") + scale_fill_discrete(name = "Taxon") +
  theme_bw() + theme(panel.border = element_blank(), panel.grid.major = element_blank(),axis.text.x = element_text(angle = 90),
                     panel.grid.minor = element_blank(), axis.line = element_line(colour = "black"), text=element_text(size=15))

im<-read.csv(file="./Prism/Insulin_male.csv", header=T)
im.m<-melt(im)

ggplot(im.m,aes(x=variable, y=value, fill=variable)) + geom_boxplot() +geom_jitter() + ylab("Serum Insulin (pg/ml)") +xlab("") + scale_fill_discrete(name = "Taxon") +
  theme_bw() + theme(panel.border = element_blank(), panel.grid.major = element_blank(),axis.text.x = element_text(angle = 90),
                     panel.grid.minor = element_blank(), axis.line = element_line(colour = "black"), text=element_text(size=15))


in.f<-read.csv(file="./Prism/Insulin_female.csv", header=T)
in.f.m<-melt(in.f)

ggplot(in.f.m,aes(x=variable, y=value, fill=variable)) + geom_boxplot() +geom_jitter() + ylab("Serum Insulin (pg/ml)") +xlab("") + scale_fill_discrete(name = "Taxon") +
  theme_bw() + theme(panel.border = element_blank(), panel.grid.major = element_blank(),axis.text.x = element_text(angle = 90),
                     panel.grid.minor = element_blank(), axis.line = element_line(colour = "black"), text=element_text(size=15))


m.le<-read.csv(file="./Prism/Leptin_male.csv", header=T)
m.le.m<-melt(m.le)

ggplot(m.le.m,aes(x=variable, y=value, fill=variable)) + geom_boxplot() +geom_jitter() + ylab("Serum Leptin (pg/ml)") +xlab("") + scale_fill_discrete(name = "Taxon") +
  theme_bw() + theme(panel.border = element_blank(), panel.grid.major = element_blank(),axis.text.x = element_text(angle = 90),
                     panel.grid.minor = element_blank(), axis.line = element_line(colour = "black"), text=element_text(size=15))


le.f<-read.csv(file="./Prism/Leptin_female.csv", header=T)
le.f.m<-melt(le.f)

ggplot(le.f.m,aes(x=variable, y=value, fill=variable)) + geom_boxplot() +geom_jitter() + ylab("Serum Leptin (pg/ml)") +xlab("") + scale_fill_discrete(name = "Taxon") +
  theme_bw() + theme(panel.border = element_blank(), panel.grid.major = element_blank(),axis.text.x = element_text(angle = 90),
                     panel.grid.minor = element_blank(), axis.line = element_line(colour = "black"), text=element_text(size=15))


mr<-read.csv(file="./Prism/Resistin_male.csv", header=T)
mr.m<-melt(mr)

ggplot(mr.m,aes(x=variable, y=value, fill=variable)) + geom_boxplot() +geom_jitter() + ylab("Serum Resistin (pg/ml)") +xlab("") + scale_fill_discrete(name = "Taxon") +
  theme_bw() + theme(panel.border = element_blank(), panel.grid.major = element_blank(),axis.text.x = element_text(angle = 90),
                     panel.grid.minor = element_blank(), axis.line = element_line(colour = "black"), text=element_text(size=15))


fr<-read.csv(file="./Prism/Resistin_female.csv", header=T)
fr.m<-melt(fr)

ggplot(fr.m,aes(x=variable, y=value, fill=variable)) + geom_boxplot() +geom_jitter() + ylab("Serum Resistin (pg/ml)") +xlab("") + scale_fill_discrete(name = "Taxon") +
  theme_bw() + theme(panel.border = element_blank(), panel.grid.major = element_blank(),axis.text.x = element_text(angle = 90),
                     panel.grid.minor = element_blank(), axis.line = element_line(colour = "black"), text=element_text(size=15))

gf<-read.csv(file="./Prism/Ghrelin_female.csv", header=T)
gf.m<-melt(gf)

ggplot(gf.m,aes(x=variable, y=value, fill=variable)) + geom_boxplot() +geom_jitter() + ylab("Serum Ghrelin (pg/ml)") +xlab("") + scale_fill_discrete(name = "Taxon") +
  theme_bw() + theme(panel.border = element_blank(), panel.grid.major = element_blank(),axis.text.x = element_text(angle = 90),
                     panel.grid.minor = element_blank(), axis.line = element_line(colour = "black"), text=element_text(size=15))


gm<-read.csv(file="./Prism/Resistin_male.csv", header=T)
gm.m<-melt(gm)

ggplot(gm.m,aes(x=variable, y=value, fill=variable)) + geom_boxplot() +geom_jitter() + ylab("Serum Ghrelin (pg/ml)") +xlab("") + scale_fill_discrete(name = "Taxon") +
  theme_bw() + theme(panel.border = element_blank(), panel.grid.major = element_blank(),axis.text.x = element_text(angle = 90),
                     panel.grid.minor = element_blank(), axis.line = element_line(colour = "black"), text=element_text(size=15))




